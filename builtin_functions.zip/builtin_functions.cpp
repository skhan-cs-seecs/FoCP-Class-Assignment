// Name   : Your Name
// CMS ID : Your CMS ID
// Assignment: Own implementation of 20 built-in functions.
// Each my_xxx function re-implements the built-in xxx function,
// and main() compares both results.

#include <iostream>
#include <vector>
#include <string>
#include <cmath>
#include <algorithm>
#include <numeric>
#include <cstdlib>
#include <cstring>
#include <memory>
#include <utility>
using namespace std;

// ---------- <cmath> ----------
// 1. ceil(x): round up to nearest integer
double my_ceil(double x) {
    long long i = (long long)x;
    return (x > i) ? i + 1 : i;
}
// 2. floor(x): round down to nearest integer
double my_floor(double x) {
    long long i = (long long)x;
    return (x < i) ? i - 1 : i;
}

// ---------- <algorithm> ----------
// 3. sort(start, end): ascending order (insertion sort)
template <typename It>
void my_sort(It first, It last) {
    for (It i = first; i != last; ++i) {
        auto key = *i;
        It j = i;
        while (j != first && *(j - 1) > key) {
            *j = *(j - 1);
            --j;
        }
        *j = key;
    }
}
// 4. reverse(start, end): reverse elements in range
template <typename It>
void my_reverse(It first, It last) {
    while (first != last && first != --last) {
        auto tmp = *first;
        *first = *last;
        *last = tmp;
        ++first;
    }
}
// 5. find(start, end, value): position of element in range
template <typename It, typename T>
It my_find(It first, It last, const T& value) {
    for (; first != last; ++first)
        if (*first == value) return first;
    return last;
}

// ---------- <cctype> ----------
// 6. isspace(c): checks for whitespace
bool my_isspace(char c) {
    return c == ' ' || c == '\t' || c == '\n' || c == '\v' || c == '\f' || c == '\r';
}
// 7. isalpha(c): checks if character is alphabetic
bool my_isalpha(char c) {
    return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z');
}

// ---------- <string> ----------
// 8. push_back(ch): append character to end
void my_push_back(string& s, char ch) {
    s += ch;
}
// 9. stoi(str): convert string to integer
int my_stoi(const string& s) {
    size_t i = 0;
    while (i < s.size() && my_isspace(s[i])) i++;
    int sign = 1;
    if (i < s.size() && (s[i] == '-' || s[i] == '+')) {
        if (s[i] == '-') sign = -1;
        i++;
    }
    int result = 0;
    while (i < s.size() && s[i] >= '0' && s[i] <= '9') {
        result = result * 10 + (s[i] - '0');
        i++;
    }
    return sign * result;
}

// ---------- <numeric> ----------
// 11. gcd(a, b): greatest common divisor (Euclid)
int my_gcd(int a, int b) {
    while (b != 0) {
        int t = a % b;
        a = b;
        b = t;
    }
    return a < 0 ? -a : a;
}
// 10. lcm(a, b): least common multiple
int my_lcm(int a, int b) {
    if (a == 0 || b == 0) return 0;
    int r = (a / my_gcd(a, b)) * b;
    return r < 0 ? -r : r;
}
// 12. iota(start, end, value): fill range with sequential values
template <typename It, typename T>
void my_iota(It first, It last, T value) {
    for (; first != last; ++first) {
        *first = value;
        ++value;
    }
}

// ---------- <cstdlib> ----------
// 13. rand(): pseudo-random integer (linear congruential generator)
static unsigned long my_seed = 1;
int my_rand() {
    my_seed = my_seed * 1103515245UL + 12345UL;
    return (int)((my_seed / 65536) % 32768);
}
// 14. exit(status): terminate the program immediately
void my_exit(int status) {
    cout << "my_exit called with status " << status << endl;
    exit(status);
}

// ---------- <utility> ----------
// 15. swap(a, b): swap values of two objects
template <typename T>
void my_swap(T& a, T& b) {
    T tmp = static_cast<T&&>(a);
    a = static_cast<T&&>(b);
    b = static_cast<T&&>(tmp);
}
// 16. move(x): convert object to rvalue reference
template <typename T>
typename remove_reference<T>::type&& my_move(T&& x) {
    return static_cast<typename remove_reference<T>::type&&>(x);
}

// ---------- <memory> ----------
// 17. addressof(x): actual address of an object (ignores overloaded &)
template <typename T>
T* my_addressof(T& x) {
    return reinterpret_cast<T*>(&const_cast<char&>(reinterpret_cast<const volatile char&>(x)));
}

// ---------- <cstring> ----------
// 18. strlen(s): length of a C-string
size_t my_strlen(const char* s) {
    size_t n = 0;
    while (s[n] != '\0') n++;
    return n;
}

// ---------- <string> ----------
// 19. stod(str): convert text to number (double)
double my_stod(const string& s) {
    size_t i = 0;
    while (i < s.size() && my_isspace(s[i])) i++;
    double sign = 1;
    if (i < s.size() && (s[i] == '-' || s[i] == '+')) {
        if (s[i] == '-') sign = -1;
        i++;
    }
    double result = 0;
    while (i < s.size() && s[i] >= '0' && s[i] <= '9') {
        result = result * 10 + (s[i] - '0');
        i++;
    }
    if (i < s.size() && s[i] == '.') {
        i++;
        double scale = 0.1;
        while (i < s.size() && s[i] >= '0' && s[i] <= '9') {
            result += (s[i] - '0') * scale;
            scale /= 10;
            i++;
        }
    }
    return sign * result;
}

// ---------- container ----------
// 20. front(): access the first element
template <typename Container>
auto& my_front(Container& c) {
    return *c.begin();
}

// ======================= main =======================
int main() {
    cout << "Name: Your Name | CMS ID: Your CMS ID\n\n";

    cout << "1.  ceil(2.3)      : mine=" << my_ceil(2.3)  << " builtin=" << ceil(2.3)  << "\n";
    cout << "2.  floor(-2.3)    : mine=" << my_floor(-2.3) << " builtin=" << floor(-2.3) << "\n";

    vector<int> a = {5, 2, 9, 1, 7}, b = a;
    my_sort(a.begin(), a.end());
    sort(b.begin(), b.end());
    cout << "3.  sort           : mine="; for (int x : a) cout << x << ' ';
    cout << " builtin="; for (int x : b) cout << x << ' '; cout << "\n";

    my_reverse(a.begin(), a.end());
    reverse(b.begin(), b.end());
    cout << "4.  reverse        : mine="; for (int x : a) cout << x << ' ';
    cout << " builtin="; for (int x : b) cout << x << ' '; cout << "\n";

    auto p1 = my_find(a.begin(), a.end(), 7);
    auto p2 = find(b.begin(), b.end(), 7);
    cout << "5.  find(7)        : mine index=" << (p1 - a.begin())
         << " builtin index=" << (p2 - b.begin()) << "\n";

    cout << "6.  isspace(' ')   : mine=" << my_isspace(' ') << " builtin=" << (isspace(' ') != 0) << "\n";
    cout << "7.  isalpha('A')   : mine=" << my_isalpha('A') << " builtin=" << (isalpha('A') != 0) << "\n";

    string s = "Hell";
    my_push_back(s, 'o');
    cout << "8.  push_back('o') : result=" << s << "\n";
    cout << "9.  stoi(\"-1234\")  : mine=" << my_stoi("-1234") << " builtin=" << stoi("-1234") << "\n";

    cout << "10. lcm(4,6)       : mine=" << my_lcm(4, 6) << " builtin=" << lcm(4, 6) << "\n";
    cout << "11. gcd(12,18)     : mine=" << my_gcd(12, 18) << " builtin=" << gcd(12, 18) << "\n";

    vector<int> seq(5);
    my_iota(seq.begin(), seq.end(), 10);
    cout << "12. iota(from 10)  : mine="; for (int x : seq) cout << x << ' '; cout << "\n";

    cout << "13. rand()         : mine=" << my_rand() << ", " << my_rand() << ", " << my_rand() << "\n";

    int x = 1, y = 2;
    my_swap(x, y);
    cout << "15. swap(1,2)      : x=" << x << " y=" << y << "\n";

    string src = "moved text";
    string dst = my_move(src);
    cout << "16. move           : dst=\"" << dst << "\" src size=" << src.size() << "\n";

    cout << "17. addressof(x)   : " << (my_addressof(x) == addressof(x) ? "same as builtin" : "different") << "\n";
    cout << "18. strlen(\"Hello\") : mine=" << my_strlen("Hello") << " builtin=" << strlen("Hello") << "\n";
    cout << "19. stod(\"3.14\")   : mine=" << my_stod("3.14") << " builtin=" << stod("3.14") << "\n";

    vector<int> v = {42, 7, 8};
    cout << "20. front()        : mine=" << my_front(v) << " builtin=" << v.front() << "\n";

    cout << "\n";
    my_exit(0);   // 14. exit(status) - last, since it ends the program
}
