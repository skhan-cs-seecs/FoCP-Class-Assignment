// Name   : Muhammad Shahram
// CMS ID : 591749
// Program: Demonstration of 20 basic C++ functions

#include <iostream>
#include <cmath>       
#include <cctype>      
#include <cstdlib>     
#include <cstring>     
#include <algorithm>   
#include <vector>
using namespace std;

int main() {
    cout << "Name : Muhammad Shahram" << endl;
    cout << "CMS ID : 591749" << endl << endl;

    // ---------- Math functions (<cmath>) ----------
    cout << "--- Math functions ---" << endl;
    cout << "sin(1.5708)   = " << sin(1.5708) << endl;     // sine of an angle (radians)
    cout << "asin(1)       = " << asin(1) << endl;         // inverse sine (result in radians)
    cout << "log(2.718)    = " << log(2.718) << endl;      // natural logarithm
    cout << "fmod(10, 3)   = " << fmod(10, 3) << endl;     // remainder of floating-point division
    cout << "fabs(-7.5)    = " << fabs(-7.5) << endl;      // absolute value of a decimal number
    cout << endl;

    // ---------- Character functions (<cctype>) ----------
    cout << "--- Character functions ---" << endl;
    char ch = 'a';
    cout << "toupper('a')  = " << (char)toupper(ch) << endl;        // converts to uppercase
    cout << "isalnum('A')  = " << (isalnum('A') != 0) << endl;      // letter or digit?
    cout << "isupper('A')  = " << (isupper('A') != 0) << endl;      // uppercase letter?
    cout << "islower('a')  = " << (islower('a') != 0) << endl;      // lowercase letter?
    cout << "ispunct('!')  = " << (ispunct('!') != 0) << endl;      // punctuation mark?
    cout << endl;

    // ---------- Conversion function (<cstdlib>) ----------
    cout << "--- Conversion function ---" << endl;
    double num = atof("3.14");                                      // string -> double
    cout << "atof(\"3.14\")  = " << num << endl;
    cout << endl;

    // ---------- C-string functions (<cstring>) ----------
    cout << "--- C-string functions ---" << endl;
    char first[50] = "Hello";
    char second[50];
    strcpy(second, " World");                                       // copy one string into another
    strcat(first, second);                                          // join second to the end of first
    cout << "strcpy + strcat = " << first << endl;
    cout << "strlen(first)   = " << strlen(first) << endl;          // number of characters
    cout << "strcmp(\"abc\", \"abc\") = " << strcmp("abc", "abc") << endl;  // 0 means equal
    cout << endl;

    // ---------- Algorithm functions (<algorithm>) ----------
    cout << "--- Algorithm functions ---" << endl;
    vector<int> v = {10, 20, 30, 40, 50};
    cout << "binary_search(v, 30) = " << binary_search(v.begin(), v.end(), 30) << endl; // v must be sorted
    cout << "max_element(v)       = " << *max_element(v.begin(), v.end()) << endl;      // largest value
    cout << "min_element(v)       = " << *min_element(v.begin(), v.end()) << endl;      // smallest value

    fill(v.begin(), v.end(), 7);                                    // set every element to 7
    cout << "after fill(v, 7)     = ";
    for (int x : v) cout << x << " ";
    cout << endl << endl;

    // ---------- abort() (<cstdlib>) ----------
    // abort() stops the program immediately with an error.
    // Here it only runs if the string is empty, so it will not run now.
    if (strlen(first) == 0) {
        abort();
    }
    cout << "abort() was not needed, program finished normally." << endl;

    return 0;
}
